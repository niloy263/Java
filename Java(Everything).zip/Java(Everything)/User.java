package interfaces;
import java.lang.*;
import classes.*;

public interface BookOperation
{
	void insertBook(Book b);
	Book getBook(int BookId);
	void showAllBooks();
}