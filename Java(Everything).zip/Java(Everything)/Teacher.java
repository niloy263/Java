


public class Teacher {
        String name;
    static String department = "CS";
    String gender;
    public Teacher(){
    }
        public Teacher (String n, String g)
    {
    this.name = n;
    this.gender = g;
    }
    public void printInfo() {
       System.out.println("Teacher Name:" +name);
       System.out.println("Teacher Department:" +department);
       System.out.println("Teacher Gender:" +gender);
       
    }
    
}

