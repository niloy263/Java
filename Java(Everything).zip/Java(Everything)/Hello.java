public class Hello { 
    public static void main(String args[]) 
    { 
        System.out.println("Niloy Kundu your java programming process is running congrats man"); 
    } 
}