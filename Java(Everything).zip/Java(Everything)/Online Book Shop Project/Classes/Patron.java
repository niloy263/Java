package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import Interfaces.IBasicOperations;

public abstract class Patron implements IBasicOperations {
    int id = 0;
    String name = "";
    String departmentName = "";
    String email = "";
    String contactNo = "";
    String address = "";
    double amount = 0.00;
    

    void setId(int id){
        this.id=id;
        
    }
    void setName(String name){
        this.name=name;

    }
    void setDepartmentName(String departmentName){
        this.departmentName=departmentName;

    }
    void setEmail(String email){
        this.email=email;

    }
    void setContactNo(String contactNo){
        this.contactNo=contactNo;

    }
    void setAddress(String address){
        this.address=address;

    }
    void setAmount(int amount){
        this.amount=amount;

    }
    int getId(){
        return id ;
    }
    String getName(){
        return name;
    }
    String  getDepartmentName(){
        return departmentName;
    }
    String getEmail(){  
        return email;
    }
    String getContact(){
        return  contactNo;
    }
     String getAddress(){
         return address;
    }
    double getAmount()
	{
         return  amount;
    }
    abstract void showInfo();
}
