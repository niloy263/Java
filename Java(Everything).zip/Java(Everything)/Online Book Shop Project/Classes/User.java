package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;
import java.util.Stack;

import Interfaces.UserOperations;

public class User extends Patron implements UserOperations{
    Stack<User> users = new Stack<User>();
    String userId;
    String guardianName;
    String guardianContactNo;

    public User(String sid, String gname, String gcontactinfo){
        userId = sid;
        guardianName = gname;
        guardianContactNo = gcontactinfo;
    }
    public User(){
    }

    void setUserId(String userId){
        this.userId=userId;

    }
    void setGuardianName(String guardianName){
        this.guardianName=guardianName;

    }
    void setGuardianContactNo(String guardianContactNo){
        this.guardianContactNo=guardianContactNo;

    }
    String getUserId(){
        return userId;
    }
    String getGuardianName(){
        return guardianName;

    } 
     String getGuardianContactNo(){
         return guardianContactNo;

    }
     void showInfo(User s){
         System.out.println("The User ID no. is : " + s.userId);
         System.out.println("The User guardian's Name is : " + s.guardianName);
         System.out.println("The User guardian's Contact No. is : " + s.guardianContactNo);
     }
     void showInfo(){
         
     }
    
     public void insertUser(User s){
         users.push(s);
     }
     public void removeUser(User s){
         users.pop();
     }
     public User getUser(String userId){
         User[] arr1 = new User[users.size()];
                    arr1 = users.toArray(arr1);
                    User s = null ;               

                    for (int i = 0; i < users.size(); i++) {
                        if (arr1[i].userId.equals(userId)) {
                            System.out.println("\nUser found !");
                             s = arr1[i];                           
                            break;
                        }
                    }
       return s;
     }
      public User getUser(int userId){
        // neeeded to overload the method as the userid variabe in the class was of type String  
        return null;
      }
     public void showAllUsers(){
         User[] arr1 = new User[users.size()];
         int count = 1;
                    arr1 = users.toArray(arr1);
                    System.out.println(" \nShowing all the users !");
                    for (int i = 0; i < arr1.length; i++,count++) {                       
                        System.out.println("User no." + count + " had the ID no. = " + arr1[i].userId);
                    }
     }
      public void borrow (Patron p, Book b){
        
    }
     public void returnBook(Patron p , Book b ){
         
     }
     public void fine (Patron p,double amount){
         
     }    
}
