package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import Interfaces.BookOperations;

public class Author {

    int id = 0;
    String name = "";
    String email = "";
    
    public Author(int i,String n, String em){
        id =i;
        name = n;
        email = em;
    }

    void setId(int id) {
        this.id = id;
    }

    void setName(String name) {
        this.name = name;
    }

    void setEmail(String email) {
        this.email = email;
    }

    int getId() {
        return id;
    }

    String getName() {
        return name;
    }

    String getEmail() {
        return email;
    }
}
