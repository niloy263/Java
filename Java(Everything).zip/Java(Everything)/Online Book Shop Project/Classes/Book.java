package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import Interfaces.BookOperations;

public class Book implements BookOperations {
    Stack<Book> books = new Stack<Book>();

    int id = 0;
    String title = "";
    String subtitle = "";
    Author author = null;
    Publisher publisher = null;
    Double price = 0.0;
    
    public Book(int i, String ttle, String sub,Author aut,Publisher publ, Double price ){
        id=i;
        title = ttle;
        subtitle = sub;
        author = aut;
        publisher = publ;
        this.price = price;
        
    }

    void setId(int id) {
        this.id = id;
    }

    void setTitle(String title) {
          this.title = title;
    }

    void setSubTitle(String subTitle) {
           this.subtitle = subTitle;
    }

    void setAuthor(Author author) {
         this.author = author;
    }

    void setPublisher(Publisher publisher) {
           this.publisher = publisher;
    }

    void setPrice(double price) {
          this.price = price;
    }
    public void insertBook(Book b){
        books.push(b);
    }

    public Book getBook(int bookId){
        Book[] arr1 = new Book[books.size()];
                    arr1 = books.toArray(arr1);
                     Book t = null;               

                    for (int i = 0; i < books.size(); i++) {
                        if (arr1[i].id ==bookId) {
                            System.out.println("\n Book found !");
                            t = arr1[i];
                            break;
                        }
                    }
     return t;     
        
    }

    public void showAllBooks(){
         int count= 1;
          Book[] arr1 = new Book[books.size()];
                    arr1 = books.toArray(arr1);
                     Book t = null; 
                     System.out.println(" \nShowing the information of all the Books !");
                     for (int i = 0; i < arr1.length; i++,count++) {                       
                        System.out.println("Book no." + count + " had the ID no. = " + arr1[i].id);
                    }
    }
    void borrow (Patron p, Book b){
        
    }
     void returnBook(Patron p , Book b ){
         
     }
     void fine (Patron p,double amount){
         
     }    
}
