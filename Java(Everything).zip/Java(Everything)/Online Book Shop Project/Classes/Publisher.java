package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import Interfaces.BookOperations;

public class Publisher {

    int id = 0;
    String name = "";
    String contactNo = "";
    
    public Publisher(int i,String n, String c){
        id =i;
        name = n;
        contactNo = c;
    }

    void setId(int id) {
        this.id = id;
    }

    void setName(String name) {
        this.name = name;
    }

    void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    int getId() {
        return id;
    }

    String getName() {
        return name;
    }

    String getContactNo() {
        return contactNo;
    }
}
