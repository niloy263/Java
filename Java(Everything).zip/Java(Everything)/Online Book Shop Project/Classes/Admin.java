package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;
import java.util.Stack;
import java.util.Stack;

import Interfaces.AdminOperations;

public class Admin extends Patron implements AdminOperations{
    Stack<Admin> admins = new Stack<Admin>();
     
	String adminId;
    public Admin(String tcrId){
         adminId = tcrId;
     }

    void setAdminId(String adminId){
        this.adminId=adminId;

    }
    String getAdminId(){
        return adminId;
    }
    public void insertAdmin(Admin t){
         admins.push(t);
     }
    public Admin getAdmin(String adminId){
        Admin[] arr1 = new Admin[admins.size()];
                    arr1 = admins.toArray(arr1);
                    Admin t = null;               

                    for (int i = 0; i < admins.size(); i++) {
                        if (arr1[i].adminId.equals(adminId)) {
                            System.out.println("\n Admin found !");
                            t = arr1[i];
                            break;
                        }
                    }
     return t; 
    }
    public Admin getAdmin(int adminId){
        //method overloading seemed easier than multiple type castings
          return null;
    }
    public void showAllAdmin(){
        int count= 1;
        Admin[] arr1 = new  Admin[admins.size()];
                    arr1 = admins.toArray(arr1);
                     System.out.println(" \nShowing the information of all the admins !");
                      Admin s = admins.peek();
                    for (int i = 0; i < arr1.length; i++,count++) {                       
                        System.out.println(" Admin no." + count + " had the ID no. = " + arr1[i].adminId);
                    }
    }
    void showInfo(){
         
     }
    public void borrow (Patron p, Book b){
        
    }
     public void returnBook(Patron p , Book b ){
         
     }
     public void fine (Patron p,double amount){
         
     }    
}
