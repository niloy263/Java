import java.lang.*;
import Classes.*;
import Interfaces.*;
import java.util.Scanner;
import java.util.Stack.*;
import fileio.*;

public class Start {

    public static void main(String[] main) {

        Scanner sc = new Scanner(System.in);
        boolean a = true;
        while (a) {
            int choose = 0;
            int x = 1;
            while (x == 1) {
                System.out.print("1. User System \n" + "2.  Admin System\n" + "3. Book System \n" + "4. Basic Operations\n" + "5. Exit \n");
                System.out.print("Choose one option = ");
                try {
                    choose = sc.nextInt();
                    x++;
                } catch (Exception e) {
                    System.out.println("\ninvalid option chosen");
                    break;
                }
                if (choose < 1 || choose > 5) {
                    System.out.println("\ninvalid option chosen");
                    break;
                }
            }
            if (choose == 1) {
                x = 1;
                int userChoice = 0;
                while (x == 1) {

                    System.out.println("Options for User System:");
                    System.out.print("1.Insert New User\n" + "2.Search by userId\n" + "3.Show All user\n");
                    System.out.print("Choose one option=");
                    try {
                        userChoice = sc.nextInt();
                        x++;
                    } catch (Exception e) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                    if (userChoice < 0 || userChoice > 3) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                }

                //User insertion
                if (userChoice == 1) {
                    String userID = "";
                    String Gname = "";
                    String Gcontact = "";
                    int flag = 0;
                    while (flag == 0) {
                        try {
                            sc.nextLine();
                            System.out.println("insert the User's ID no. :");
                            userID = sc.nextLine();
                            System.out.println("insert the Guardian Name :");
                            Gname = sc.nextLine();
                            System.out.println("insert the Guardian Contact no. :");
                            Gcontact = sc.nextLine();

                            flag++;

                        } catch (Exception e) {
                            System.out.print("invalid information provided \n please try again !");
                        }

                    }
                    User s = new User(userID, Gname, Gcontact);
                     System.out.print("User insertion successful !");
                    s.insertUser(s);
                } //search User by Id no.
                else if (userChoice == 2) {
                    String userID = "";
                    int flag = 0;
                    while (flag == 0) {
                        try {
                            System.out.println("insert the User's ID no. :");
                            sc.nextLine();
                            userID = sc.nextLine();
                            flag++;

                        } catch (Exception e) {
                            System.out.println("invalid User ID provided \n please try again !");
                        }
                        User desiredUser = new User();
                        desiredUser = desiredUser.getUser(userID);
                        if (desiredUser == null) {
                            System.out.println("\nSorry ! \nUser not found !");
                        }
                    }

                } //User info print
                else if (userChoice == 3) {
                    User s = new User();
                    s.showAllUsers();

                } //back-up exception handling check
                else {
                    System.out.println(" \nOperation could not be performed! ");
                }

            } //option 2 operations
            else if (choose == 2) {
                 Admin tch = null;
                x = 1;
                int tChoice = 0;
                while (x == 1) {

                    System.out.println("Options for  Admin System:");
                    System.out.print("1.Insert New  Admin\n" + "2.Search by  Adminid\n" + "3.Show All Admin\n");
                    System.out.print("Choose one option = ");
                    try {
                        tChoice = sc.nextInt();
                        x++;
                    } catch (Exception e) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                    if (tChoice < 1 || tChoice > 3) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                }

                //Admin insertion
                if (tChoice == 1) {
                    String tID = "";

                    int flag = 0;
                    while (flag == 0) {
                        try {
                            sc.nextLine();
                            System.out.println("insert the Admin's ID no. :");
                            tID = sc.nextLine();
                            flag++;

                        } catch (Exception e) {
                            System.out.print("invalid information provided \n please try again !");
                        }

                    }
                     Admin s = new  Admin(tID);
                    s.insertAdmin(s);
                    System.out.print(" Admin insertion successful !");
                } //search  Admin by Id no.
                else if (tChoice == 2) {
                    String tID = "";
                    int flag = 0;
                    while (flag == 0) {
                        try {
                            System.out.println("insert the  Admin's ID no. :");
                            sc.nextLine();
                            tID = sc.nextLine();
                            flag++;

                        } catch (Exception e) {
                            System.out.println("invalid  Admin ID provided \n please try again !");
                        }

                    }

                    tch = tch.getAdmin(tID);
                    if (tch == null) {
                        System.out.println("\nSorry ! \nAdmin not found !");
                    }
                } //Admin info print
                else if (tChoice == 3) {
                    tch.showAllAdmin();
                } //back-up exception handling check
                else {
                    System.out.println(" \nOperation could not be performed! ");
                }

            } // Admin operation ended 
            //Book operation started
            else if (choose == 3) {
                Book b = null;
                x = 1;
                int bChoice = 0;
                while (x == 1) {

                    System.out.println("Options for Book System:");
                    System.out.print("1.Insert New Book\n" + "2.Search by Bookid\n" + "3.Show All Books\n");
                    System.out.print("Choose one option = ");
                    try {
                        bChoice = sc.nextInt();
                        x++;
                    } catch (Exception e) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                    if (bChoice < 1 || bChoice > 3) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                }

                //Book insertion
                if (bChoice == 1) {
                    
                    int bookid = 0;
                    String title = "";
                    String subtitle = "";
                    Author author = null;
                    Publisher publisher = null;
                    Double price = 0.0;

                    int flag = 0;
                    while (flag == 0) {
                        try {
                            
                            System.out.println("insert the Book ID no. :");
                            bookid = sc.nextInt();
                           sc.nextLine();
                           System.out.println("insert the Book title :");
                           title = sc.nextLine();
                           System.out.println("insert the Book subtitle :");
                           subtitle = sc.nextLine();
                           System.out.println("insert the Book author'a id :");
                           int aid = sc.nextInt();
                           sc.nextLine();
                           System.out.println("insert the Book author's name :");
                           String nam = sc.nextLine();
                           System.out.println("insert the Book author's email :");
                           String eml = sc.nextLine();
                           author = new Author(aid,nam,eml);
                           System.out.println("insert the Book publisher'a id :");
                           int pid = sc.nextInt();
                           sc.nextLine();
                           System.out.println("insert the Book publisher's name :");
                           String pnam = sc.nextLine();
                           System.out.println("insert the Book publisher's email :");
                           String pcontactNo = sc.nextLine();
                           publisher  = new Publisher(pid,pnam,pcontactNo);
                           System.out.println("insert the Book's price :");
                           price = sc.nextDouble();
                           
                           flag++;

                        } catch (Exception e) {
                            System.out.print("invalid information provided \n please try again !");
                        }

                    }
                    Book s = new Book(bookid,title,subtitle,author,publisher,price);
                    s.insertBook(s);
                    System.out.print("Book successfully inserted ! \n");
                    
                }
                // Book by Id no.
                else if (bChoice == 2) {
                    int bID = 0;
                    int flag = 0;
                    while (flag == 0) {
                        try {
                            System.out.println("insert the Book's ID no. :");
                            bID = sc.nextInt();
                            flag++;

                        } catch (Exception e) {
                            System.out.println("invalid Book ID provided \n please try again !");
                        }

                    }

                    b = b.getBook(bID);
                    if (b == null) {
                        System.out.println("\nSorry ! \nBook not found !");
                    }
                } 
                //book info print
                else if (bChoice == 3) {
                    b.showAllBooks();
                } //back-up exception handling check
                else {
                    System.out.println(" \nOperation could not be performed! ");
                }

            }
            
           //Basic Operations
            else if (choose == 4) {
                Book b = null;
                x = 1;
                int bopt = 0;
                while (x == 1) {

                    System.out.println("Options for Book Borrow/Return/Lost System:");
                    System.out.print("1.Borrow Book\n" + "2.Return Book\n" + "3.Add Fine\n");
                    System.out.print("Choose one option = ");
                    try {
                        bopt = sc.nextInt();
                        x++;
                    } catch (Exception e) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                    if (bopt < 1 || bopt > 3) {
                        System.out.println(" \ninvalid option chosen");
                        break;
                    }
                }

                //Book insertion
                if (bopt == 1) {
                    
                    int bookid = 0;
                    String title = "";
                  
                    int flag = 0;
                     String identity = "";
                      String id = "";
                    while (flag == 0) {
                        try {
                            
                            System.out.println("insert the Book ID no. :");
                            bookid = sc.nextInt();
                           sc.nextLine();
                           System.out.println("enter your identity , user or admin ?");
                            identity = sc.nextLine();
                           System.out.println("insert your id :");
                           id = sc.nextLine();
                           flag++;

                        } catch (Exception e) {
                            System.out.print("invalid information provided \n please try again !");
                        }

                    }
                    if(identity.toLowerCase() == "user"){
                        User st = null;
                        st = st.getUser(id);
                        b = b.getBook(bookid);
                        st.borrow(st, b);
                         System.out.print(" Congratulations ! \nBook successfully Borrowed ! \n");
                    }
                    else if(identity.toLowerCase() == "Admin"){
                        Admin t = null;
                        t = t.getAdmin(id);
                        b = b.getBook(bookid);
                        t.borrow(t, b);
                        System.out.print(" Congratulations ! \nBook successfully Borrowed ! \n");
                    }
                    else{
                       System.out.println("Patron Not Found"); 
                    }
                }
                //return Book .
                else if (bopt == 2) {
                    int bID = 0;
                    int pid = 0;
                    String id ="" ;
                    String identity = "";
                    int flag = 0;
                    while (flag == 0) {
                        try {
                            System.out.println("enter your identity , user or admin ?");
                            identity = sc.nextLine();
                           System.out.println("insert your id :");
                           id = sc.nextLine();
                            System.out.println("insert the patron's ID no. :");
                            pid = sc.nextInt();
                            System.out.println("insert the book's ID no. :");
                            bID = sc.nextInt();
                            flag++;

                        } catch (Exception e) {
                            System.out.println("invalid user ID provided \n please try again !");
                        }

                    }
                     if(identity.toLowerCase() == "user"){
                        User st = null;
                        st = st.getUser(id);
                        b = b.getBook(bID);
                        st.returnBook(st, b);
                         System.out.print("Book successfully Returned ! \n Thank You");
                    }
                    else if(identity.toLowerCase() == "admin"){
                        Admin t = null;
                        t = t.getAdmin(id);
                        b = b.getBook(bID);
                        t.returnBook(t, b);
                        System.out.print("Book successfully Returned ! \n Thank You");
                    }else{
                       System.out.println("Patron Not Found"); 
                    }
                } 
                //ADD FINE 
                else if (bopt == 3) {
                    String id ="" ;
                    String identity = "";
                    double amount = 0.0;
                    System.out.println("enter your identity , user or admin ?");
                            identity = sc.nextLine();
                           System.out.println("insert your id :");
                           id = sc.nextLine();
                           System.out.println("insert the amount of fine :");
                           amount = sc.nextDouble();
                           if(identity.toLowerCase() == "user"){
                        User st = null;
                        st = st.getUser(id);
                        st.fine(st, amount);
                        System.out.print("The amount of fine is added to your account ! \n Thank You");
                    }
                    else if(identity.toLowerCase() == "admin"){
                        Admin t = null;
                        t = t.getAdmin(id);
                        t.fine(t, amount);
                        System.out.print("The amount of fine is added to your account ! \n Thank You");
                    }
                    else{
                         System.out.println("Patron Not Found");
                    }
                 
                } 
                //back-up exception handling check
                else {
                    System.out.println(" \nOperation could not be performed! ");
                }

            }
             else if (choose == 5) {
                 System.out.println(" \nYou are leaving from the application! ");
                 break;
             }
             else{
                 System.out.println(" \nOperation could not be performed! ");
             }

            // Retry option for user
            System.out.println(" Press anykey to Try again ! ");
            String retry = "";
            try {
                retry = sc.nextLine();
            } catch (Exception e) {
            }

        }
        

    }

}
