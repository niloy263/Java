package Interfaces;

import Classes.User;

public interface UserOperations {

    void insertUser(User s);

    void removeUser(User s);

    User getUser(int userId);

    void showAllUsers();
}
