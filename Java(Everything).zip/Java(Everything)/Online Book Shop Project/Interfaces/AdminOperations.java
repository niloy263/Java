package Interfaces;

import Classes.Admin;

public interface AdminOperations {
    void insertAdmin(Admin t);
    Admin getAdmin(int adminId);
    void showAllAdmin();
}
