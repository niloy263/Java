import java.lang.*;

public class Start
{
  public static void main(String []args)
  {
    Course c1 = new Course();
    c1.setCourseName("Java");
    c1.setCourseCode("123");
    c1.setCourseCredit("4");
	   
    Student s1 = new Student();
    s1.setSid("19-39883-1");
    s1.setCourse(c1);
    

    Course c2 = new Course("java", "123", "4");
    Student s2 = new Student("19-39881-1", c2);
    
    System.out.println("Student ID: "+s1.getSid());
    System.out.println("CourseName: "+s1.getCourse().getCourseName());
    System.out.println("CourseCode: "+s1.getCourse().getCourseCode());
    System.out.println("CourseCredit: "+s1.getCourse().getCourseCredit());
	
	System.out.println("Student ID: "+s2.getSid());
    System.out.println("CourseName: "+s2.getCourse().getCourseName());
    System.out.println("CourseCode: "+s2.getCourse().getCourseCode());
    System.out.println("CourseCredit: "+s2.getCourse().getCourseCredit());
    
  }
}