import java.lang.*;

public class Course
{
  public String courseName;
  public String courseCode;
  public String courseCredit;
  
  public Course()
  {
    System.out.println();
  }
  public Course(String courseName, String courseCode, String courseCredit)
  {
    System.out.println();
    this.courseName = courseName;
    this.courseCode = courseCode;
    this.courseCredit = courseCredit;
    
  }
  
  public void setCourseName(String courseName)
  {
    this.courseName = courseName;
  }
  public void setCourseCode(String courseCode)
  {
    this.courseCode = courseCode;
  }
  public void setCourseCredit(String courseCredit)
  {
    this.courseCredit = courseCredit;
  }
  public String getCourseName(){return courseName;}
  public String getCourseCode(){return courseCode;}
  public String getCourseCredit(){return courseCredit;}
  
  public void showDetails()
  {
    System.out.println("CourseName: "+courseName);
    System.out.println("CourseCode: "+courseCode);
    System.out.println("CourseCredit: "+courseCredit);
  }
}