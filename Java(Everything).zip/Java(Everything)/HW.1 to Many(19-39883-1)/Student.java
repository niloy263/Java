import java.lang.*;

public class Student
{
  private String sid;
  //private Course Course;
  Course course= new Course();
  
  public Student()
  {
    System.out.println();
  }
  public Student(String s, Course cour)
  {
    System.out.println();
    this.sid = s;
    this.course = cour;
  }
  public void setSid(String s)
  {
    this.sid = s;
  }
  public void setCourse(Course course)
  {
    this.course = course;
  }
  public String getSid(){return sid;}
  public Course getCourse(){return course;}
  
  public void showDetails()
  {
    System.out.println("Student ID: "+sid);
    System.out.println("CourseName: "+course.courseName);
    System.out.println("CourseCode: "+course.courseCode);
    System.out.println("CourseCredit: "+course.courseCredit);    
  }
}