import java.lang.*;

public class Start
{
  public static void main(String []args)
  {
    Passport p1 = new Passport();
    p1.setPageNumber("fourty");
    p1.setAccountHolderName("Niloy");
    p1.setID("1111111");
    
    Student s1 = new Student();
    s1.setSid("19-39883-1");
    s1.setPassport(p1);
    
    s1.showDetails();
    System.out.println();
    Passport p2 = new Passport("fourty", "Niloy", "1111111");
    Student s2 = new Student("19-39883-1", p2);
    
    System.out.println("Student ID: "+s2.getSid());
    System.out.println("Page Number: "+s2.getPassport().getPageNumber());
    System.out.println("Account Holder Name: "+s2.getPassport().getAccountHolderName());
    System.out.println("ID: "+s2.getPassport().getID());
    
  }
}