import java.lang.*;

public class Passport
{
  public String pageNumber;
  public String accountHolderName;
  public String id;
  
  public Passport()
  {
    System.out.println("Empty Account");
  }
  public Passport(String pageNum, String acHolderName, String id_)
  {
    System.out.println("Para Account");
    this.pageNumber = pageNum;
    this.accountHolderName = acHolderName;
    this.id = id_;
    
  }
  
  public void setPageNumber(String pageNum)
  {
    this.pageNumber = pageNum;
  }
  public void setAccountHolderName(String accountHolderName)
  {
    this.accountHolderName = accountHolderName;
  }
  public void setID(String id_)
  {
    this.id = id_;
  }
  public String getPageNumber(){return pageNumber;}
  public String getAccountHolderName(){return accountHolderName;}
  public String getID(){return id;}
  
  public void showDetails()
  {
    System.out.println("Page Number: "+pageNumber);
    System.out.println("Account Holder Name: "+accountHolderName);
    System.out.println("ID: "+id);
  }
}