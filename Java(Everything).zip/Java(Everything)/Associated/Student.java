import java.lang.*;

public class Student
{
  private String sid;
  private Passport passport;
  
  public Student()
  {
    System.out.println("Empty Student");
  }
  public Student(String s, Passport pass)
  {
    System.out.println("Para Student");
    this.sid = s;
    this.passport = pass;
  }
  public void setSid(String s)
  {
    this.sid = s;
  }
  public void setPassport(Passport passport)
  {
    this.passport = passport;
  }
  public String getSid(){return sid;}
  public Passport getPassport(){return passport;}
  
  public void showDetails()
  {
    System.out.println("Student ID: "+sid);
    System.out.println("Page Number: "+passport.pageNumber);
    System.out.println("Account Holder Name: "+passport.accountHolderName);
    System.out.println("ID: "+passport.id);    
  }
}