import java.util.Scanner;
class Niloy{
  public static void main(String [] agrs)
  {
    Scanner sc= new Scanner(System.in);
    System.out.println("Input the value of s1");
    String s1= sc.nextLine();
    System.out.println("Input the value of s2");
    String s2= sc.nextLine();
    if (s1==s2)
    {
      System.out.println("Yes");
    }
    else
    {
      System.out.println("No");
    }
    System.out.println("Input the value of s3");
    String s3=sc.nextLine();
    if(s1.equals(s3))
    {
      System.out.println("Yes");
    }
    else
    {
      System.out.println("No");
    }
    
    if(s2.equals(s3))
    {
      System.out.println("Yes");
    }
    else
    {
      System.out.println("No");
    }
    
    
    System.out.println(s1.length());
    
    System.out.println(s1.concat(s3));
    
    System.out.println(s1);
    
    System.out.println(s3);
    
    String s4= s1.substring(2,7);
    
    System.out.println(s4);
    
    System.out.println(s1);
    
    s1= s1.substring(3,7);
    
    System.out.println(s1);
    
    System.out.println("Input s5");
    
    String s5=sc.nextLine();
    
    s5=s5.toUpperCase();
    
    System.out.println(s5);
    
    
  }
}