import java.lang.*;
public class Library
{
  
  public String libraryName;
  public String location;
  Book [ ] books;
  public Library(){}
  public Library(String libraryName, String location, int sizeOfArray)
  {
    this.libraryName = libraryName;
    this.location = location;
    Book books []= new Book[sizeOfArray];
  }
  int i= 0;
  public void addBook(Book b){
    books[i].equals(b);
    i++;
//    for(int i=0; i<books.length; i++){
//      if(books[i]!=null){}
//      else{
//        books[i]=b;
//      }
//    }
  }
  void removeBook(Book b){
    for(int i=0; i<books.length-1; i++){
      if(books[i].equals(b)){
        books[i].equals(books[i+1]);
        books[i+1].equals(books[i+1+1]);
      }
    }
  }
  int countTotalBooksIntheLibrary( ){
    int count=0;
    for(int i=1; i<books.length; i++){
      if(books[i]!= null){
        count++;
      }
    }
    return count;
  }
  void showDetails()
  {
    System.out.println("Library Name:" +libraryName);
    System.out.println("Library Location:" +location);
  }
}