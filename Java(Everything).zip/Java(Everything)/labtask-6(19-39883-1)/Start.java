import java.lang.*;

public class Start
{
 public static void main(String []args)
 {
   Book b1 = new Book("a", "p", "c", 10, 100);
   Book b2 = new Book("d", "e", "f", 20, 200);
   Book b3 = new Book("g", "h", "i", 30, 300);
   Book b4 = new Book("j", "k", "l", 40, 400);
   Book b5 = new Book("m", "n", "o", 50, 500);
   Library l1 = new Library("Kiko Library","Talpukurpar",10);
   l1.addBook(b1);
   l1.addBook(b2);
   l1.addBook(b3);
   l1.addBook(b4);
   l1.showDetails();
   l1.removeBook(b2);
   l1.countTotalBooksIntheLibrary();
   l1.addBook(b5);
   l1.countTotalBooksIntheLibrary();
 }
}