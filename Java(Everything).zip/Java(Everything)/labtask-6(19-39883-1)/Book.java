import java.lang.*;
public class Book
{
  public String bookId;
  public String bookTitle;
  public String authorName;
  public int publicationYear;
  public int availableQuantity; 
  
  Book(){}
  Book(String bookId, String bookTitle, String authorName, int publicationYear, int availableQuantity)
  {
    this.bookId = bookId;
    this.bookTitle = bookTitle;
    this.authorName = authorName;
    this.publicationYear = publicationYear;
    this.availableQuantity = availableQuantity;
  }
  void showDetails(){
    System.out.println("Book ID:" +bookId);
    System.out.println("Book Title:" +bookTitle);
    System.out.println("Author Name:" +authorName);
    System.out.println("Publication Year:" +publicationYear);
    System.out.println("Available Quantity:" +availableQuantity);
  }
  
}