import java.lang.*;
public class ScientificCalculator extends BasicCalculator implements ScientificCalculation {
	ScientificCalculator( ){
		super();
	}
	ScientificCalculator (double v1, double v2){
		super(v1,v2);
	}
	public double tothePow() 
	{
		long result = 1;
		while (value2 != 0)
		{
         result *= value1;
         --value2;
		}
     return result;
    }
	
}
