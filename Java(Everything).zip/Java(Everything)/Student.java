


public class Student {
     String name;
    String id;
    public Student(){
    }
      public Student (String n,  String i)
    {
    this.name = n;
    this.id = i;
    }
       public void printInfo() {
       System.out.println("Student Name:" +name);
       System.out.println("Student ID:" +id);
}
}

