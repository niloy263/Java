public class Test
{
     public static void main(String args[])
	 {
	    Person p1 = new Person("NILOY", "123-1", 20, "Bangladeshi","M");
		
        p1.showDetails();		
	 }
}