class Person
{
	String name;
	String nid;
	int age;
	String nationality;
	String gender;
	Person(String name, String nid, int age, String nationality, String gender)
	{
		this.name = name;
		this.nid = nid;
		this.age = age;
		this.nationality = nationality;
		this.gender = gender;
	public void showDetails()
	{
		System.out.println("Name:" +name);
		System.out.println("NID:" +nid); 
		System.out.println("Age:" +age);
		System.out.println("Nationality:" +nationality);
		System.out.println("Gender:" +gender);
	}
}