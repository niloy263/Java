
public class Start {

 
    public static void main(String[] args) {
        Student st1 = new Student("Niloy", "19-1");
        Teacher te1 = new Teacher("Eitam", "Female");
         st1.printInfo();
        te1.printInfo();
    }
    
}
