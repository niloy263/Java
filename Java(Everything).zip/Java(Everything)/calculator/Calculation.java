import java.lang.*;
public interface Calculation {
	double add( );
	double subtract( );
	double multiply( );
	double divide( ); 
}