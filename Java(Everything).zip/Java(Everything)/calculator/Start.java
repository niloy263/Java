import java.lang.*;
public class Start {

	public static void main(String[] args) {
		ScientificCalculator c1= new ScientificCalculator();
		//ScientificCalculator c2= new ScientificCalculator(12,5);
		System.out.println("The summation of the first two default numbers is :"+c1.add());
		System.out.println("The subtraction of the first two default numbers is :"+c1.subtract());
		System.out.println("The division of the first two default numbers is :"+c1.divide());
		System.out.println("The multiplication of the first two default numbers is :"+c1.multiply());
		System.out.println("The value of the first number to the power second default number is: "+c1.tothePow());
		
		/*
		System.out.println("The summation of the second two given numbers is :"+c2.add());
		System.out.println("The subtraction of the second two given numbers is :"+c2.subtract());
		System.out.println("The division of the second two givennumbers is :"+c2.divide());
		System.out.println("The multiplication of the second two given numbers is :"+c2.multiply());
		System.out.println("The value of the first number to the power second given number is"+c2.tothePow());
		*/

	}

}
