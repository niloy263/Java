import java.lang.*;
public interface ScientificCalculation 
{
	double toThePow();

}