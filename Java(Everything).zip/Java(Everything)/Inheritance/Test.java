public class Test{
	public static void main(String[] args){
		Student s1 = new Student("Niloy","19398831",20,"Bangladeshi","Male","19-39883-1","CSE","Spring",0.0);
		s1.showDetails();
		
	}
}