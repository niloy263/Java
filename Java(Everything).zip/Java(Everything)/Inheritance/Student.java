public class Student extends Person{
	String Sid;
	String dept;
	String semester;
	double cgpa;
	Student(String name, String nid,int age,String nationality, String gender,String Sid,String dept, String semester,double c)
	{
		this.name = name;
		this.nid = nid;
		this.age = age;
		this.nationality = nationality;
		this.gender = gender;
		this.Sid = Sid;
		this.dept = dept;
		this.semester = semester;
		this.cgpa = c;
	}
	public void showDetails()
	{
		System.out.println("Name: "+name);
		System.out.println("Nid: "+nid);
		System.out.println("Age: "+age);
		System.out.println("Nationality: "+nationality);
		System.out.println("Gender: "+gender);
		System.out.println("Sid: "+Sid);
		System.out.println("dept: "+dept);
		System.out.println("semester: "+semester);
		System.out.println("cgpa: "+cgpa);
	}
}