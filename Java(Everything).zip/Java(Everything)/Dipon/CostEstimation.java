import java.lang.*;
public class CostEstimation {

      public static void main(String[] args) {

       Book o1=new Book(65,9);
	   o1.showInfo();
    
    
    
    
    
    }
}