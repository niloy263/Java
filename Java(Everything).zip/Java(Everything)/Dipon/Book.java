import java.lang.*;
public class Book {
    
private int numberOfPages;
private int costPerPages;

    public Book() {
    }

    public Book(int costPerPages,int numberOfPages ) {
        this.costPerPages = costPerPages;
     this.numberOfPages= numberOfPages;
    }
	 public void showInfo()
  {
    System.out.println("costPerPages: "+costPerPages);
    System.out.println("numberOfPages: "+numberOfPages);
  }
}
	