import java.lang.*;
public class Shape
{
   final double x;
   public Shape()
   {System.out.println("E-Shape");}
   public Shape(double x)
   {
	   System.out.println("E-Shape");
	   this.x = x;
   }
   public void setX(double x)
   {this.x = x;}
   public double getX()
   {return x;}
   public final double calArea();
}