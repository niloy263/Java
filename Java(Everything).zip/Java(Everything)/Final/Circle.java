import java.lang.*;

public class Circle
{
	public Circle(){System.out.println("E-Circle");}
	public Circle(final double x)
	{
		super(x);
		System.out.println("P-Circle");
	}
	public final double calArea()
	{
		return 3.1416 * x * x;
	}
	
}