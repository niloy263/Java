import java.lang.*;
final class Shape
public class Rectangle
{
	private final double y;
	
	public Rectangle(){System.out.println("E-Rectangle");}
	public Rectangle(double x, double y)
	{
		super(x);
		System.out.println("P-Rectangle");
		this.y = y;
	}
	public void setY(double y){this.y = y;}
	public double getY(){return y;}
	public final double calArea()
	{
		return x * y;
	}
	
}