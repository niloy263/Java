public class Employee {

    public Employee() {
    }

    public String empName;
    public double salary;

    public String getEmpName() {
        return empName;
    }

    public void setEmptName(String empName) {
        this.empName = empName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
 }
    }