public class Department {
  private static int deptId;
  private static String deptName;
  
  public Department() {
  }
  public Department(int dept_Id, String dept_Name){
    this.deptId= dept_Id;
    this.deptName= dept_Name;
  }
  
  
  public static int getDeptId() {
    return deptId;
  }
  
  public void setDeptName(int deptID) {
    this.deptId = deptID;
  }
  
  public static String getDeptName() {
    return deptName;
  }
  
  public void setDeptName(String dept_Name) {
    this.deptName = dept_Name;
  }
  
}