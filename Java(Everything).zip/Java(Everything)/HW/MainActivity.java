public class MainActivity{ 
  public static void main(String[ ] args){ 
    Department cs = new Department(1, "Computer Science");
    Faculty f1 = new Faculty("Tony Stark", 100000, 12, cs); 
    f1.showInfo( ); 
  } 
}