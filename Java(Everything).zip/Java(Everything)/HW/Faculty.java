public class Faculty extends Employee
{
  Faculty( ){
  }
  public int teachingHour;
  Department d1= new Department();
  
  public Faculty (String emp_Name, double sal, int th, Department dept)
  {
    
    d1= dept;
    empName = emp_Name;
    salary = sal;
    teachingHour = th;
  }
  public String getEmpName() {
    return empName;
  }
  
  public void setEmptName(String empName) {
    this.empName = empName;
  }
  
  public double getSalary() {
    return salary;
  }
  
  public void setSalary(double salary) {
    this.salary = salary;
  }
  public int getTeachingHour() {
    return teachingHour;
  }
  
  public void setTeachingHour(int th) {
    this.teachingHour = th;
  }
  
  public void showInfo()
  {
    System.out.println("Name: "+empName);
    System.out.println("Salary: "+salary);
    System.out.println("Teaching Hour:: "+teachingHour);
    System.out.println("Department Name: "+ d1.getDeptName());    
  }
}

